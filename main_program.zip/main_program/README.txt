Some information about the main_program

    * 3Dgas.cpp is put for H=2 sigma.  If you want to change the height, you have to go to 3Dgas.cpp file and modify the value.
    * If you want make a specific number of trayectories, change the number of particles or change the values of alpha, you have to go to 3Dgas.sh and 
      change the parameters:
            + alpha = inelasticity
            + Nx*Ny*Nz = number of particles  
            + ns = number of trayectory
    * The files with velocities and positions for each trajectories are saved inside DataSim.
    * Python files inside DataSim handle with the data in order to obtain temperature evol, coefficients of stationary temps (beta) and stationary temps. You have to run it in this order:
            +1)    pressures_2.1.py
            +2)  mean_PresTemp_vs_time_2.2.py
            +3) beta_Txyz_vs_alpha_2.3.py
IMPORTANT: in order to obtain the results in parallel version, you have to put the THE ENTIRE pathway in  ofstream myfile(watheverpath/R_blabla.dat).